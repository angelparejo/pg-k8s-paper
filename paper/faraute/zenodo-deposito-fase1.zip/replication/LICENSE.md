# Licencias del depósito

Este depósito usa **licencias distintas para datos/documentación y para código**:

- **Datos y documentación** (`data/`, `*.md`, suplemento, manifiestos): **CC-BY-4.0**
  (Creative Commons Atribución 4.0 Internacional). https://creativecommons.org/licenses/by/4.0/
- **Código** (`execution-package/manifiestos/scripts/*.py`, `*.sh`): **MIT** (texto abajo).

Al citar, atribuya a: Angel A. Parejo R. (Universidad de Carabobo) y el artículo asociado
(ver `CITATION.cff`).

---

## MIT License (código)

Copyright (c) 2026 Angel A. Parejo R.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

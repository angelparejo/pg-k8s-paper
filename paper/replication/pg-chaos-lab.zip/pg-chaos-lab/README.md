# pg-chaos-lab — Laboratorio de inyección de fallos PostgreSQL en Kubernetes

Kit ejecutable de la subsección **IV.E "Diseño experimental propuesto"** del
artículo (v1-5). Valida los invariantes de consistencia (RPO), disponibilidad
(RTO) y durabilidad sobre la interacción multicapa I(S) = f(O × C × D).

## Entorno objetivo (versiones verificadas)
| Componente | Versión |
|---|---|
| Kubernetes | 1.34.6 |
| CloudNativePG (operador) | 1.28.0 (ya instalado) |
| PostgreSQL | 16.13 |
| CSI Huawei (SAN / Fibre Channel) | 4.10.1 |
| Calico | 3.31.4 |
| Chaos Mesh | 2.7.x (instalación offline, scoped) |
| Zalando Postgres Operator | v1.13.x + Spilo 16 (importar) |

Entorno **air-gapped**: todas las imágenes se importan con
`ctr -n k8s.io images import` (ver `images/`).

## Diseño factorial
2 operadores (CNPG, Zalando/Patroni) × 1 backend (SAN/FC) ×
escenarios {F1, F2, F3} + análisis de sensibilidad F4 (0/20/50/100 ms) × **n = 10**.

| Fase | Fallo | Herramienta | Riesgo |
|---|---|---|---|
| F1 | Terminación del pod primario | PodChaos `pod-kill` | Mínimo |
| F2 | Indisponibilidad sostenida (sustituto de fallo de nodo)* | PodChaos `pod-failure` 10 min | Bajo |
| F3 | Partición de red del primario | **NetworkPolicy (Calico)** — sin Chaos Mesh | Bajo, reversión = `kubectl delete` |
| F4 | Latencia de E/S +20/50/100 ms | IOChaos (FUSE, **no toca la SAN**) | Bajo |

\* El comportamiento de K8s/CSI ante nodo perdido (desalojo, detach/attach) no se
reproduce: queda como análisis teórico (Tabla I) y limitación declarada. En este
entorno productivo **no se ejecuta drain/cordon**.

## Orden de ejecución
```bash
# 0) Etiquetar nodos del laboratorio e importar imágenes (images/)
kubectl label node <worker-N> pg-chaos-lab/member=true

# 1) Aislamiento
kubectl apply -f 00-namespace/

# 2) Chaos Mesh scoped (10-chaos-mesh/INSTALL-offline.md)

# 3) Operadores y clústeres (ajustar storageClass: huawei-san-fc al real)
kubectl apply -f 20-operators/cnpg/cluster-cnpg.yaml
#   Zalando: renderizar chart offline con postgres-operator-values-airgapped.yaml,
#   aplicar, y despues: kubectl apply -f 20-operators/zalando/cluster-zalando.yaml
kubectl -n pg-chaos-lab get pods -w    # esperar 3/3 en cada cluster

# 4) Carga y verificador
kubectl apply -f 30-workload/
kubectl -n pg-chaos-lab exec deploy/pgbench-cnpg -- pgbench -i -s 10 -h pg-cnpg-rw -U lab labdb

# 5) Experimentos (n=10 por combinación), p. ej.:
cd scripts
for r in $(seq 1 10); do ./run-experiment.sh cnpg    ../40-experiments/f1-podkill-cnpg.yaml    $r; sleep 120; done
for r in $(seq 1 10); do ./run-experiment.sh zalando ../40-experiments/f1-podkill-zalando.yaml $r; sleep 120; done
# F4: repetir por nivel (20/50/100 ms); el nivel 0 ms es la línea base sin manifiesto.

# 6) RPO desde los logs del verificador
kubectl -n pg-chaos-lab logs deploy/tx-verifier-cnpg > verifier-cnpg.log
./parse-verifier.py verifier-cnpg.log

# 7) Estadística (medianas, p95, Mann-Whitney, Kruskal-Wallis, Spearman)
./analyze.py results.csv
```

## Estructura
```
00-namespace/    aislamiento: namespace, quota, limitrange, RBAC scoped
10-chaos-mesh/   values scoped air-gapped + instalación offline
20-operators/    clúster CNPG 1.28 y clúster Zalando/Patroni (PG 16.13, SAN/FC)
30-workload/     pgbench continuo + tx-verifier (contador de verdad RTO/RPO)
40-experiments/  manifiestos F1–F4 por operador
50-metrics/      PromQL de contexto (opcional)
scripts/         orquestación, parsing y estadística sin dependencias
images/          lista de imágenes + import por ctr
docs/            artículo v1-3 → v1-5 (IEEE)
```

Leer **RUNBOOK.md** antes de tocar el clúster productivo.

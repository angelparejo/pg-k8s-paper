# Métricas y consultas (Prometheus/Grafana, opcional)

Si existe Prometheus Operator, habilitar `monitoring.enablePodMonitor: true` en
`cluster-cnpg.yaml`; Zalando expone métricas vía sidecar (ver docs del operador).
Las métricas primarias del paper (RTO/RPO) **no dependen de Prometheus**: salen
del tx-verifier y de run-experiment.sh. Prometheus añade contexto explicativo.

## PromQL de contexto
- Lag de replicación CNPG (segundos):
  `cnpg_pg_replication_lag{cluster="pg-cnpg"}`
- Rol de cada instancia CNPG (detección del instante de promoción):
  `cnpg_pg_replication_is_primary`
- Conmutaciones vistas por Patroni (Zalando):
  cambios en la métrica `patroni_master` / etiqueta `spilo-role`
- Presión de E/S durante F4 (node-exporter, nodos del lab):
  `rate(node_disk_io_time_seconds_total[1m])`

## Registro de eventos del operador (evidencia cualitativa para el paper)
kubectl -n pg-chaos-lab get events --sort-by=.lastTimestamp | grep -iE "failover|promot|switch"

# RUNBOOK — Protocolo de seguridad en clúster productivo

## Antes de la ventana (change management)
1. Change aprobado con: alcance (solo namespace `pg-chaos-lab`), ventana,
   responsables, plan de reversión (este documento).
2. Coordinar con el equipo de almacenamiento: los volúmenes del lab viven en la
   SAN Huawei real; si el OceanStor lo permite, usar un pool/tier dedicado o QoS.
   IOChaos inyecta latencia vía FUSE **dentro del pod**: no toca la cabina.
3. Verificar aislamiento ANTES de inyectar nada:
   - `kubectl -n pg-chaos-lab get resourcequota` (cuotas activas)
   - Chaos Mesh con `clusterScoped: false` (probar que un selector hacia otro
     namespace es rechazado: aplicar un PodChaos con `namespaces: [default]`
     debe fallar/no seleccionar nada).
   - chaos-daemon SOLO en nodos `pg-chaos-lab/member=true`:
     `kubectl -n pg-chaos-lab get pods -o wide | grep chaos-daemon`
4. Silenciar alertas únicamente del namespace del lab (Alertmanager: matcher
   `namespace="pg-chaos-lab"`). Nunca silenciar alertas de clúster.

## Criterios de aborto (verificar tras CADA inyección)
Abortar y revertir si cualquiera se cumple:
- Alertas activas fuera de `pg-chaos-lab`.
- Latencia p99 del API server o `etcd_disk_wal_fsync` degradadas vs. línea base.
- Presión de E/S anómala en nodos que NO son del laboratorio.
- Cualquier pod productivo reprogramado o en CrashLoop coincidente en el tiempo.

## Reversión inmediata (en orden, según fase)
```bash
# Chaos Mesh (F1/F2/F4): borrar el experimento detiene la inyección al instante
kubectl -n pg-chaos-lab delete podchaos,iochaos --all
# F3 (partición Calico):
kubectl -n pg-chaos-lab delete networkpolicy -l experiment=f3
# Congelar el laboratorio si hace falta:
kubectl -n pg-chaos-lab scale deploy pgbench-cnpg pgbench-zalando --replicas=0
```

## Entre repeticiones
- Esperar la reconstrucción completa del clúster PG (3/3 instancias, lag ~0):
  `kubectl -n pg-chaos-lab get cluster pg-cnpg` → `Cluster in healthy state`
  `kubectl -n pg-chaos-lab exec <spilo-master> -- patronictl list`
- Mínimo 120 s de reposo (cool-down) entre inyecciones.

## Al terminar la ventana
```bash
kubectl -n pg-chaos-lab delete podchaos,iochaos,networkpolicy --all
kubectl delete -f 10-chaos-mesh/chaos-mesh-rendered.yaml   # opcional: retirar Chaos Mesh
# El namespace puede conservarse entre ventanas; para desmontar todo:
# kubectl delete namespace pg-chaos-lab   (borra PVCs → coordinar con storage)
```

## Registro para el paper (reproducibilidad)
Por cada corrida conservar: `results.csv`, logs del tx-verifier, eventos
(`kubectl get events`), versión exacta de manifiestos (git tag) y la salida de
`kubectl version` / `kubectl -n pg-chaos-lab get pods -o wide`.

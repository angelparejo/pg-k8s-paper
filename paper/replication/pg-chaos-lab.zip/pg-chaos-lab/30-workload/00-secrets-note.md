# Credenciales
- CNPG crea el secret `pg-cnpg-app` (usuario `lab`, db `labdb`).
  Cadena rw: host=pg-cnpg-rw.pg-chaos-lab.svc puerto 5432.
- Zalando crea `lab.lab-pg-zalando.credentials.postgresql.acid.zalan.do`.
  Cadena rw (master): host=lab-pg-zalando.pg-chaos-lab.svc puerto 5432.
Los pods de carga/verificacion leen la password de esos secrets (ver env de cada manifiesto).
